<?php
/**
 * @author    Oceanpayment Team
 * @copyright Copyright (c) 2018 Oceanpayment.COM
 */
 

class OPCreditCardReturnModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        if(!isset($_REQUEST['account'])){
            Tools::redirect($this->context->link->getPageLink('index'));
        }
        parent::initContent();
     
        //账户
        $account = $_REQUEST['account'];
        //终端号
        $terminal = $_REQUEST['terminal'];
        //securecode
        $securecode = $this->module->getSecureCode();
        //交易流水订单号
        $payment_id = $_REQUEST['payment_id'];
        //返回网站订单号
        $order_number = $_REQUEST['order_number'];
        //交易币种
        $order_currency = $_REQUEST['order_currency'];
        //交易金额
        $order_amount = $_REQUEST['order_amount'];
        //交易状态
        $payment_status = $_REQUEST['payment_status'];
        //返回支付详情
        $payment_details = $_REQUEST['payment_details'];
        //未通过的风控规则
        $payment_risk = $_REQUEST['payment_risk'];
        //返回支付信用卡卡号
        $card_number = $_REQUEST['card_number'];
        //返回交易类型
        $payment_authType = $_REQUEST['payment_authType'];
        //备注
        $order_notes = $_REQUEST["order_notes"];
        //数据签名
        $back_signValue = $_REQUEST["signValue"];
        //返回解决办法
        $payment_solutions = $_REQUEST['payment_solutions'];
        
        //校验源字符串
        $local_signValue = hash("sha256",$account.$terminal.$order_number.$order_currency.$order_amount.$order_notes.$card_number.
            $payment_id.$payment_authType.$payment_status.$payment_details.$payment_risk.$securecode);
        
        //是否推送
        $response_type = $_REQUEST['response_type'];
        
        //用于支付结果页面显示响应代码
        $getErrorCode = explode(':', $payment_details);
        $ErrorCode = $getErrorCode[0];


        $this->context->smarty->assign([
            'is_guest' 			=> (($this->context->customer->is_guest) || $this->context->customer->id == false),
        	'order_currency'	=> $order_currency,
            'order_amount' 		=> $order_amount,
            'order_number'		=> $order_number,
        	'payment_status'	=> $payment_status,
        	'payment_details'	=> $payment_details,
        	'payment_solutions'	=> $payment_solutions,
        ]);


        $this->setTemplate('module:opcreditcard/views/templates/front/order-confirmation.tpl');
    }
 

}
